package com.icecreamlabs.app;

import java.io.File;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;

import com.mysql.jdbc.Blob;
import com.mysql.jdbc.Driver;

public class Fetcher {

	public static void main(String[] args) {

		// Declaring necessary Objects
		Connection con = null;
		File file = null;
		File file2 = null;
		Statement stmt = null;
		ResultSet rs = null;
		int count = 1;

		try {
			// Class.forName("com.mysql.jdbc.Driver").newInstance();
			// Something Wrong with the newInstance()...getting red cross while using
			// So using Driver Interface to load the driver

			Driver driverRef = new Driver();// 1. Loading the Driver
			DriverManager.registerDriver(driverRef);

			String dbUrl = "jdbc:mysql://localhost:3306/image_db?useSSL=false";
			String user = "j2ee";
			String password = "j2ee";
			con = DriverManager.getConnection(dbUrl, user, password);// 2.Get the DB connection via Driver

			file = new File("C:/Users/sumit/Desktop/pic");// Creating the Folder on the Desktop with name pic
			boolean fol = file.mkdir();

			// Checking whether Folder is created or not
			if (fol == true) {
				System.out.println("Folder Created");
			} else {
				System.out.println("Unable to create Folder");
			}

			String query = " select * from image_table ";

			stmt = con.createStatement();
			rs = stmt.executeQuery(query);// 3.Issuing the SQL queries via Connection

			// 4. Processing the result Returned by Database
			while (rs.next()) {

				file2 = new File("C:/Users/sumit/Desktop/pic/image_" + count + ".jpg");// Creating the jpg file with the
																						// Desire name in pic folder

				java.sql.Blob blob = (Blob) rs.getBlob("image");// Getting the blob file from ResultSet object
				InputStream in = blob.getBinaryStream();// Converting the blob to Binary Stream
				BufferedImage image = ImageIO.read(in);// Converting the Binary stream in to Real Image
				ImageIO.write(image, "jpg", file2); // Saving the Image to file
				count++;
				System.out.println("Saving Image to folder....");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			// 5. Closing all the Connection
			try {
				if (con != null) {
					con.close();
				}

			} catch (Exception e1) {
				e1.printStackTrace();
			}
			try {
				if (stmt != null) {
					stmt.close();
				}

			} catch (Exception e2) {
				e2.printStackTrace();
			}
			try {
				if (rs != null) {
					rs.close();
				}

			} catch (Exception e3) {
				e3.printStackTrace();
			}
		}

	}

}
